# Insurance Claim Settlement Bias Analysis Dashboard

## Overview
This Streamlit dashboard performs comprehensive analysis of insurance claim settlement data to detect and quantify bias in the approval/repudiation process.

## Features
- Descriptive Analysis with cross-tabulations
- Diagnostic Bias Analysis (Age, Income, Zone-wise)
- Supervised ML Classification (KNN, Decision Tree, Random Forest, Gradient Boosting)
- Model Performance with ROC curves, confusion matrices, and FP/FN analysis
- Feature Importance analysis

## Files
- app.py - Main Streamlit application
- requirements.txt - Python dependencies
- Insurance.csv - Dataset

## Setup
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Cloud
1. Create GitHub repo with these files
2. Go to share.streamlit.io and connect repo
3. Deploy

## Key Findings
- Income Bias: Very Low income faces 51.9% repudiation vs 32% overall
- Zone Bias: Massive variation across teams (3.4% to 100%)
- Best Model: Gradient Boosting (AUC = 0.786)
